import java.util.ArrayList;
import java.util.List;

public class ExpenseManager {
    private List<Expense> expenses;


    public ExpenseManager() {
        expenses = new ArrayList<>();
    }
    public void addExpense(Expense expense) {
        expenses.add(expense);
        System.out.println("Expense added: "+ expense.getExpenseName());

    }
    public void viewAllExpenses() {
        for (Expense expense : expenses) {
            System.out.println(expense);
        }

    }
    private Expense findExpenseByID(int id) {
        for (Expense expense : expenses) {
            if (expense.getExpenseID() == id) {
                return expense;
            }
        }
        System.out.println("Expense not found");
        return null;
    }
    public void updateExpense(int id, String newName, double newAmount, String newDescription) {
       //loop thru expense list
        for (Expense expense : expenses) {
            if (expense.getExpenseID() == id){
                //update fields
                expense.setExpenseName(newName);
                expense.setExpenseAmount(newAmount);
                expense.setExpenseDescription(newDescription);
                System.out.println("Expense with ID "+ id+" updated");
                return;
            }
        }
        System.out.println("Expense with ID "+ id+" not found");
    }
    public void deleteExpense(int id) {
       for(int i=0;i<expenses.size();i++){
           if(expenses.get(i).getExpenseID() == id){
               expenses.remove(i);
               System.out.println("Expense with ID "+ id+" deleted");
               return;
           }
       }
       System.out.println("Expense with ID "+ id+" not found");
    }
    public double getTotalExpenses() {
        double total = 0;
        for (Expense expense : expenses) {
            total += expense.getExpenseAmount();
        }
        return total;

    }


}
