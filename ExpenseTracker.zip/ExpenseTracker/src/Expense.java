public class Expense {
    private int expenseID;
    private String expenseName;
    private double expenseAmount;
    private String expenseDescription;
    //constructor
    public Expense(int expenseID, String expenseName, double expenseAmount , String expenseDescription) {
        this.expenseID = expenseID;
        this.expenseName = expenseName;
        this.expenseAmount = expenseAmount;
        this.expenseDescription = expenseDescription;
    }

    public int getExpenseID() {
        return expenseID;
    }
    public void setExpenseID(int expenseID) {
        this.expenseID = expenseID;
    }
    public String getExpenseName() {
        return expenseName;
    }
    public void setExpenseName(String expenseName) {
        this.expenseName = expenseName;
    }
    public double getExpenseAmount() {
        return expenseAmount;
    }
    public void setExpenseAmount(double expenseAmount) {
        if (expenseAmount > 0) {
            this.expenseAmount = expenseAmount;
        }else{
           throw new IllegalArgumentException("Expense Amount cannot be negative");
        }
    }
    public String getExpenseDescription() {
        return expenseDescription;
    }
    public void setExpenseDescription(String expenseDescription) {
        this.expenseDescription = expenseDescription;
    }

    @Override
    public String toString() {
        return "AddExpense{" +
                "expenseID=" + expenseID +
                ", expenseName='" + expenseName + '\'' +
                ", expenseAmount=" + expenseAmount +
                ", expenseDescription='" + expenseDescription + '\'' +
                '}';
    }
}
