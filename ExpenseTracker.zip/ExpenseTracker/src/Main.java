public class Main {
    public static void main(String[] args) {
        // create manager
        ExpenseManager manager = new ExpenseManager();

        // create expenses
        Expense e1 = new Expense(1,"Food",12.59,"Work Lunch");
        Expense e2 = new Expense(2,"Vehicle",40.29,"Gas");
        Expense e3 = new Expense(3,"Work",8.99,"Phone charger");
        //add expenses
        manager.addExpense(e1);
        manager.addExpense(e2);
        manager.addExpense(e3);
        //view all expenses
        System.out.println("\nAll Expenses:");
        manager.viewAllExpenses();
        //update expense
        manager.updateExpense(2,"Gas",48.99,"Filled up tank(more gas)");
        //delete expense
        manager.deleteExpense(1);
        //view all expenses
        System.out.println("\nAll Expenses after modification:");
        manager.viewAllExpenses();
        // get total Expenses
        System.out.println("\nTotal Expenses: "+manager.getTotalExpenses());


    }
}